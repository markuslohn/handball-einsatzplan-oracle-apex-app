prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.7'
,p_default_workspace_id=>9848763511374192
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'HANDBALL'
);
wwv_flow_api.create_page(
 p_id=>1
,p_user_interface_id=>wwv_flow_api.id(17680705175370854)
,p_name=>'Home'
,p_alias=>'HOME'
,p_step_title=>'Einsatzplan'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_last_updated_by=>'HANDBALL'
,p_last_upd_yyyymmddhh24miss=>'20210925222134'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(17694214749370955)
,p_plug_name=>'Einsatzplan'
,p_icon_css_classes=>'app-icon'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(17591326415370786)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('<p>Herzlich Willkommen in der App f\00FCr die Einsatzplanung des TSV Lengfeld und TG W\00FCrzburg. Um die Einhaltung der strengen Hygienevorschriften f\00FCr einen Spieltag gew\00E4hrleisten zu k\00F6nnen, gibt es vielf\00E4ltige Aufgaben zu erledigen. Wir haben diese Aufga')
||unistr('ben zu Rollen zusammengefa\00DFt.'),
'</p><br><br>',
'',
'<p>',
unistr('Mit dieser App wird es Dir erm\00F6glicht, sich als Helfer f\00FCr eines oder mehrere Spiele an einem Spieltag als Helfer einzutragen.</p><br>'),
'',
'<p>',
unistr('Nutze die Listenansicht oder Kalenderansicht. Du findest dort jeweils alle Heimspiele aufgelistet. W\00E4hle ein Spiel aus und trage Dich mit Deinem <b>Vor- und Nachnamen</b> ein. Wenn Du Deine Email-Adresse noch in Klammern hinzuf\00FCgst, k\00F6nnen wir Dich a')
||unistr('uch kurzfristig \00FCber \00C4nderungen informieren. '),
'</p>'))
,p_plug_query_num_rows=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_api.component_end;
end;
/
