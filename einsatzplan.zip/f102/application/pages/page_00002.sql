prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.7'
,p_default_workspace_id=>9848763511374192
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'HANDBALL'
);
wwv_flow_api.create_page(
 p_id=>2
,p_user_interface_id=>wwv_flow_api.id(17680705175370854)
,p_name=>'Hallen'
,p_alias=>'HALLEN'
,p_page_mode=>'MODAL'
,p_step_title=>'Hallen'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#:ui-dialog--stretch'
,p_protection_level=>'C'
,p_last_updated_by=>'HANDBALL'
,p_last_upd_yyyymmddhh24miss=>'20210925174942'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(17862522976396273)
,p_plug_name=>'Report 1'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(17584058070370782)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'TABLE'
,p_query_table=>'ESP_SPORTHALLEN'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_IR'
,p_prn_page_header=>'Report 1'
);
wwv_flow_api.create_worksheet(
 p_id=>wwv_flow_api.id(17862957586396273)
,p_name=>'Report 1'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'Noch keine Sporthallen angelegt.'
,p_allow_report_saving=>'N'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_control_break=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_download=>'N'
,p_detail_link=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:RP:P3_HALLEN_NR:\#HALLEN_NR#\'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'HANDBALL'
,p_internal_uid=>17862957586396273
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17863021925396274)
,p_db_column_name=>'HALLEN_NR'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Hallen-Nr.'
,p_column_type=>'NUMBER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17863488327396274)
,p_db_column_name=>'HALLEN_NAME'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_column(
 p_id=>wwv_flow_api.id(17863865691396274)
,p_db_column_name=>'HALLEN_NAME_KURZ'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>unistr('Abk\00FCrzung')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>wwv_flow_api.id(17866033622666837)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'178661'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'HALLEN_NR:HALLEN_NAME:HALLEN_NAME_KURZ'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(17865225284396276)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(17862522976396273)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(17658038853370827)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Neue Halle anlegen'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:3'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(17864272783396275)
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(17862522976396273)
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(17864716865396275)
,p_event_id=>wwv_flow_api.id(17864272783396275)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(17862522976396273)
);
wwv_flow_api.component_end;
end;
/
