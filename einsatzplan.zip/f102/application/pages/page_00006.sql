prompt --application/pages/page_00006
begin
--   Manifest
--     PAGE: 00006
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.7'
,p_default_workspace_id=>9848763511374192
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'HANDBALL'
);
wwv_flow_api.create_page(
 p_id=>6
,p_user_interface_id=>wwv_flow_api.id(17680705175370854)
,p_name=>'Kalender'
,p_alias=>'KALENDER'
,p_step_title=>'Kalender'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_last_updated_by=>'HANDBALL'
,p_last_upd_yyyymmddhh24miss=>'20210925231600'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(17886692405234162)
,p_plug_name=>'Kalender'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_api.id(17595597477370788)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select sp.begegnung_nr, sp.termin_zeit "Startzeit", sp.termin_zeit + sp.dauer/24 "Endezeit", sp.altersklasse || ''-'' || sp.heim_verein_name || '' ('' || sp.begegnung_nr || '')'' "Titel", sp.saison, sp.altersklasse, sp.liga, sp.staffel, sp.spieltag, sp.hei'
||'m_verein_name "heimmannschaft", sp.gast_verein_name "gastmannschaft", hal.hallen_name "halle", hal.hallen_name_kurz "kurzel",nvl(hal.css_class,''apex-cal-grey'') css_class',
'from esp_spielplan sp, esp_sporthallen hal',
'where sp.aktiv = 1',
'and hal.hallen_nr = sp.hallen_nr',
''))
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_CSS_CALENDAR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'Startzeit'
,p_attribute_02=>'Endezeit'
,p_attribute_03=>'Titel'
,p_attribute_04=>'BEGEGNUNG_NR'
,p_attribute_05=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.::P8_BEGEGNUNG_NR:&BEGEGNUNG_NR.'
,p_attribute_07=>'N'
,p_attribute_10=>'ICAL'
,p_attribute_11=>'month:week:day:list:navigation'
,p_attribute_13=>'Y'
,p_attribute_14=>'CSS_CLASS'
,p_attribute_16=>'&"Startzeit".: &"Heimmannschaft". - &"Gastmannschaft". (&"Kurzel".) - &"Liga".'
,p_attribute_17=>'Y'
,p_attribute_18=>'24'
,p_attribute_19=>'Y'
,p_attribute_20=>'8'
,p_attribute_21=>'10'
,p_attribute_22=>'Y'
,p_attribute_23=>'3'
);
wwv_flow_api.component_end;
end;
/
