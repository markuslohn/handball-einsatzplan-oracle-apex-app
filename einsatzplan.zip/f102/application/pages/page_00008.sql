prompt --application/pages/page_00008
begin
--   Manifest
--     PAGE: 00008
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.7'
,p_default_workspace_id=>9848763511374192
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'HANDBALL'
);
wwv_flow_api.create_page(
 p_id=>8
,p_user_interface_id=>wwv_flow_api.id(17680705175370854)
,p_name=>'Einsatzplan Details'
,p_alias=>'EINSATZPLAN-DETAILS'
,p_page_mode=>'MODAL'
,p_step_title=>'Einsatzplan'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_last_updated_by=>'HANDBALL'
,p_last_upd_yyyymmddhh24miss=>'20210926000931'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(17894418526628897)
,p_plug_name=>'Einsatzplan Details'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(17567159373370774)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select sp.begegnung_nr, sp.termin_zeit, sp.altersklasse, sp.liga, sp.spieltag, sp.heim_verein_name, sp.gast_verein_name, hal.hallen_name ,ep.aufbau, ep.abbau, ep.kampfrichter_1, ep.kampfrichter_2, ep.schiedsrichter, ep.ordner_1, ep.ordner_2',
unistr(',ep.wischer,ep.verk\00E4ufer_1 "verkaeufer_1", ep.verk\00E4ufer_2 "verkaeufer_2", ep.einlass_kontrolle_1, ep.einlass_kontrolle_2,ep.mitteilung'),
'from esp_spielplan sp, esp_einsatzplan ep, esp_sporthallen hal',
'where ep.begegnung_nr(+) = sp.begegnung_nr',
'and hal.hallen_nr = sp.hallen_nr'))
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(17909994962628908)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(17568167891370774)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(17910350447628909)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(17909994962628908)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(17658038853370827)
,p_button_image_alt=>'Abbrechen'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(17912306053628912)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_api.id(17909994962628908)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(17658038853370827)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Speichern'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_button_condition=>'P8_BEGEGNUNG_NR'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(17912733564628912)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_api.id(17909994962628908)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(17658038853370827)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Speichern'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_button_condition=>'P8_BEGEGNUNG_NR'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17879003656079603)
,p_name=>'P8_VERKAEUFER_1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_api.id(17894418526628897)
,p_item_source_plug_id=>wwv_flow_api.id(17894418526628897)
,p_prompt=>unistr('Verk\00E4ufer 1')
,p_source=>'verkaeufer_1'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>255
,p_cHeight=>5
,p_field_template=>wwv_flow_api.id(17656938552370824)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_inline_help_text=>unistr('Notwendig, wenn Verkauf angeboten wird. <b>Anwesenheit</b>: Mind. 1 Stunde vor Spielbeginn beim ersten Spiel des Tages. Ansonsten sobald das Vorg\00E4ngerspiel beendet ist in der Halle erscheinen.')
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17879155892079604)
,p_name=>'P8_VERKAEUFER_2'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_api.id(17894418526628897)
,p_item_source_plug_id=>wwv_flow_api.id(17894418526628897)
,p_prompt=>unistr('Verk\00E4ufer 2')
,p_source=>'verkaeufer_2'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>255
,p_cHeight=>5
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(17656938552370824)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_inline_help_text=>unistr('Notwendig, wenn Verkauf angeboten wird. <b>Anwesenheit</b>: Mind. 1 Stunde vor Spielbeginn beim ersten Spiel des Tages. Ansonsten sobald das Vorg\00E4ngerspiel beendet ist in der Halle erscheinen.')
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17894885951628899)
,p_name=>'P8_BEGEGNUNG_NR'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_api.id(17894418526628897)
,p_item_source_plug_id=>wwv_flow_api.id(17894418526628897)
,p_prompt=>'Spiel Nr.'
,p_source=>'BEGEGNUNG_NR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(17656938552370824)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17895296752628900)
,p_name=>'P8_TERMIN_ZEIT'
,p_source_data_type=>'TIMESTAMP_TZ'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_api.id(17894418526628897)
,p_item_source_plug_id=>wwv_flow_api.id(17894418526628897)
,p_prompt=>'Termin'
,p_source=>'TERMIN_ZEIT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(17656938552370824)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17896034585628901)
,p_name=>'P8_ALTERSKLASSE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_api.id(17894418526628897)
,p_item_source_plug_id=>wwv_flow_api.id(17894418526628897)
,p_prompt=>'Altersklasse'
,p_source=>'ALTERSKLASSE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(17656938552370824)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17896408008628901)
,p_name=>'P8_LIGA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_api.id(17894418526628897)
,p_item_source_plug_id=>wwv_flow_api.id(17894418526628897)
,p_prompt=>'Liga'
,p_source=>'LIGA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(17656938552370824)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17896838548628901)
,p_name=>'P8_SPIELTAG'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_api.id(17894418526628897)
,p_item_source_plug_id=>wwv_flow_api.id(17894418526628897)
,p_prompt=>'Spieltag'
,p_source=>'SPIELTAG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(17656938552370824)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17897252388628901)
,p_name=>'P8_HEIM_VEREIN_NAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_api.id(17894418526628897)
,p_item_source_plug_id=>wwv_flow_api.id(17894418526628897)
,p_prompt=>'Heimmannschaft'
,p_source=>'HEIM_VEREIN_NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(17656938552370824)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17897685450628902)
,p_name=>'P8_GAST_VEREIN_NAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_api.id(17894418526628897)
,p_item_source_plug_id=>wwv_flow_api.id(17894418526628897)
,p_prompt=>'Gastmannschaft'
,p_source=>'GAST_VEREIN_NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(17656938552370824)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17898050345628902)
,p_name=>'P8_HALLEN_NAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_api.id(17894418526628897)
,p_item_source_plug_id=>wwv_flow_api.id(17894418526628897)
,p_prompt=>'Ort'
,p_source=>'HALLEN_NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(17656938552370824)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17898455672628902)
,p_name=>'P8_AUFBAU'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_api.id(17894418526628897)
,p_item_source_plug_id=>wwv_flow_api.id(17894418526628897)
,p_prompt=>'Aufbau'
,p_source=>'AUFBAU'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(17656938552370824)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_help_text=>unistr('Hilft beim Aufbau zu Beginn eines Spieltages. Das betrifft Verkauf, Platz f\00FCr Zuschauererfassung und Anbringung von Hinweisschildern, etc.')
,p_inline_help_text=>unistr('Wird beim ersten Spiel des Tages ben\00F6tigt. <b>Anwesenheit</b>: ca. 1,5 Stunden vor Spielbeginn sinnvoll.')
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17898881349628902)
,p_name=>'P8_ABBAU'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_api.id(17894418526628897)
,p_item_source_plug_id=>wwv_flow_api.id(17894418526628897)
,p_prompt=>'Abbau'
,p_source=>'ABBAU'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(17656938552370824)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_inline_help_text=>unistr('Wird nur nach dem letzten Spiel eines Tages ben\00F6tigt.')
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17899241724628902)
,p_name=>'P8_KAMPFRICHTER_1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_api.id(17894418526628897)
,p_item_source_plug_id=>wwv_flow_api.id(17894418526628897)
,p_prompt=>'Kampfrichter 1'
,p_source=>'KAMPFRICHTER_1'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>255
,p_cHeight=>4
,p_field_template=>wwv_flow_api.id(17656938552370824)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_inline_help_text=>'<b>Anwesenheit</b>: 35 Minuten vor Spielbeginn. Technische Besprechung beginnt 30 Minuten vor Spielbeginn.'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17899603571628903)
,p_name=>'P8_KAMPFRICHTER_2'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_api.id(17894418526628897)
,p_item_source_plug_id=>wwv_flow_api.id(17894418526628897)
,p_prompt=>'Kampfrichter 2'
,p_source=>'KAMPFRICHTER_2'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>255
,p_cHeight=>4
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(17656938552370824)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_inline_help_text=>'<b>Anwesenheit</b>: 35 Minuten vor Spielbeginn. Technische Besprechung beginnt 30 Minuten vor Spielbeginn.'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17900042638628903)
,p_name=>'P8_SCHIEDSRICHTER'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_api.id(17894418526628897)
,p_item_source_plug_id=>wwv_flow_api.id(17894418526628897)
,p_prompt=>'Schiedsrichter'
,p_source=>'SCHIEDSRICHTER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(17656938552370824)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_inline_help_text=>'Nur notwendig bei Spielen ohne offizielle Schiedsrichter!'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17900441162628903)
,p_name=>'P8_ORDNER_1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_api.id(17894418526628897)
,p_item_source_plug_id=>wwv_flow_api.id(17894418526628897)
,p_prompt=>'Ordner 1'
,p_source=>'ORDNER_1'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(17656938552370824)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('<li>pr\00FCft die Einhaltung der Abstandsregeln, Maskenpflicht und Laufwege.'),
unistr('<li>Nach dem Spiel insbesondere Hausmeistereingang pr\00FCfen (Notausgang, T\00FCre schlie\00DFt nicht richtig)')))
,p_inline_help_text=>unistr('<b>Anwesenheit</b>: Mind. 1/2 Stunde vor Spielbeginn beim ersten Spiel des Tages. Ansonsten sobald das Vorg\00E4ngerspiel beendet ist in der Halle erscheinen.')
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17900878251628903)
,p_name=>'P8_ORDNER_2'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_api.id(17894418526628897)
,p_item_source_plug_id=>wwv_flow_api.id(17894418526628897)
,p_prompt=>'Ordner 2'
,p_source=>'ORDNER_2'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(17656938552370824)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_inline_help_text=>unistr('<b>Anwesenheit</b>: Mind. 1/2 Stunde vor Spielbeginn beim ersten Spiel des Tages. Ansonsten sobald das Vorg\00E4ngerspiel beendet ist in der Halle erscheinen.')
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_item_comment=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('<li>pr\00FCft die Einhaltung der Abstandsregeln, Maskenpflicht und Laufwege.'),
unistr('<li>Nach dem Spiel insbesondere Hausmeistereingang pr\00FCfen (Notausgang, T\00FCre schlie\00DFt nicht richtig)')))
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17901275827628903)
,p_name=>'P8_WISCHER'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_api.id(17894418526628897)
,p_item_source_plug_id=>wwv_flow_api.id(17894418526628897)
,p_prompt=>'Wischer'
,p_source=>'WISCHER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(17656938552370824)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_inline_help_text=>unistr('Beim Einsatz von Jugendlichen unter 16 Jahren ist die Einverst\00E4ndniserkl\00E4rung der Eltern erforderlich. <b>Anwesenheit</b>: 15 Minuten vor Spielbeginn.')
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17902499683628904)
,p_name=>'P8_EINLASS_KONTROLLE_1'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_api.id(17894418526628897)
,p_item_source_plug_id=>wwv_flow_api.id(17894418526628897)
,p_prompt=>'Einlasskontrolle 1'
,p_source=>'EINLASS_KONTROLLE_1'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>255
,p_field_template=>wwv_flow_api.id(17656938552370824)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('<li>Sorgt daf\00FCr, dass kein Zuschauer ohne Pr\00FCfung der 3G-Regel in die Halle gelangt.'),
unistr('<li>Ferner sorgt er f\00FCr die Einhaltung des Hygienekonzeptes im Foyer.')))
,p_inline_help_text=>unistr('<b>Anwesenheit</b>: Mind. 1 Stunde vor Spielbeginn beim ersten Spiel des Tages. Ansonsten sobald das Vorg\00E4ngerspiel beendet ist in der Halle erscheinen.')
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17902897900628904)
,p_name=>'P8_EINLASS_KONTROLLE_2'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_api.id(17894418526628897)
,p_item_source_plug_id=>wwv_flow_api.id(17894418526628897)
,p_prompt=>'Einlasskontrolle 2'
,p_source=>'EINLASS_KONTROLLE_2'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_api.id(17656938552370824)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('<li>Sorgt daf\00FCr, dass kein Zuschauer ohne Pr\00FCfung der 3G-Regel in die Halle gelangt.'),
unistr('<li>Ferner sorgt er f\00FCr die Einhaltung des Hygienekonzeptes im Foyer.')))
,p_inline_help_text=>unistr('<b>Anwesenheit</b>: Mind. 1 Stunde vor Spielbeginn beim ersten Spiel des Tages. Ansonsten sobald das Vorg\00E4ngerspiel beendet ist in der Halle erscheinen.')
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(17903227080628905)
,p_name=>'P8_MITTEILUNG'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(17894418526628897)
,p_item_source_plug_id=>wwv_flow_api.id(17894418526628897)
,p_prompt=>'Mitteilung'
,p_source=>'MITTEILUNG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_api.id(17656938552370824)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_api.create_page_validation(
 p_id=>wwv_flow_api.id(17895780677628900)
,p_validation_name=>'P8_TERMIN_ZEIT must be timestamp'
,p_validation_sequence=>10
,p_validation=>'P8_TERMIN_ZEIT'
,p_validation_type=>'ITEM_IS_TIMESTAMP'
,p_error_message=>'#LABEL# must be a valid timestamp.'
,p_associated_item=>wwv_flow_api.id(17895296752628900)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(17910443156628909)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_api.id(17910350447628909)
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(17911237124628909)
,p_event_id=>wwv_flow_api.id(17910443156628909)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(17913522295628913)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Process form Einsatzplan Details'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'begin',
'',
'  update esp_einsatzplan',
'     set aufbau = :P8_AUFBAU,',
'	     abbau = :P8_ABBAU,',
'	     kampfrichter_1 = :P8_KAMPFRICHTER_1,',
'		 kampfrichter_2 = :P8_KAMPFRICHTER_2,',
'		 schiedsrichter = :P8_SCHIEDSRICHTER,',
'		 ordner_1 = :P8_ORDNER_1,',
'		 ordner_2 = :P8_ORDNER_2,',
'		 wischer = :P8_WISCHER,',
unistr('		 verk\00E4ufer_1 = :P8_VERKAEUFER_1,'),
unistr('		 verk\00E4ufer_2 = :P8_VERKAEUFER_2,'),
'		 einlass_kontrolle_1 = :P8_EINLASS_KONTROLLE_1,',
'		 einlass_kontrolle_2 = :P8_EINLASS_KONTROLLE_2',
'  where  begegnung_nr = :P8_BEGEGNUNG_NR;',
'  ',
'end'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>unistr('\00C4nderungen konnten nicht gespeichert werden.')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>unistr('\00C4nderungen gespeichert.')
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(17913997581628913)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(17913199276628912)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_api.id(17894418526628897)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Einsatzplan Details'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
